package rgms

class Publication {

    static constraints = {
    }
}
