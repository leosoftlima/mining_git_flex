package rgms

class PublicationController {

    def index() { }
}
