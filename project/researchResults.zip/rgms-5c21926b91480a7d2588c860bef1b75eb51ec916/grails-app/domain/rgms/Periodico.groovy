package rgms

class Periodico {

	String author
	String title
	String journal
	int year

	int volume
	int number
	int pageInitial
	int pageFinal

	static constraints = {
	}
}
