package rgms



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Conferencia)
class ConferenciaTests {

    void testSomething() {
       fail "Implement me"
    }
}
