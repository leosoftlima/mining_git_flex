package rgms



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(RecordController)
class RecordControllerTests {

    void testSomething() {
       fail "Implement me"
    }
}
