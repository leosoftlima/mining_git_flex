package rgms



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Publication)
class PublicationTests {

    void testSomething() {
       fail "Implement me"
    }
}
